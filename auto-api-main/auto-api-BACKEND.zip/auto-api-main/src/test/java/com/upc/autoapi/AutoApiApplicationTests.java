package com.upc.autoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
